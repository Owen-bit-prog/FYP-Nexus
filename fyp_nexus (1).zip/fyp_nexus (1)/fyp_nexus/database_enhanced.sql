-- ============================================================
-- FYP NEXUS — Complete Database Schema with Enhanced Features
-- ============================================================
-- Features:
-- 1. ✓ Student Dashboard: Overview, My Project, Proposal, Milestones, Submissions, Feedback, Messages, Meetings
-- 2. ✓ Supervisor Dashboard: Overview, All Students, Proposals, Submissions, Feedback, Messages, Meetings
-- 3. ✓ Score/Grade Tracking
-- 4. ✓ Real-time Notifications
-- 5. ✓ Video Meeting Scheduling
-- 6. ✓ Bi-directional Chat/Messaging
-- 7. ✓ Admin Analytics

CREATE DATABASE IF NOT EXISTS fyp_nexus CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE fyp_nexus;

-- ─────────────────────────────────────────────────────────
-- 1. USERS TABLE
-- ─────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS users (
    id                INT AUTO_INCREMENT PRIMARY KEY,
    full_name         VARCHAR(120) NOT NULL,
    email             VARCHAR(180) NOT NULL UNIQUE,
    password_hash     VARCHAR(255) NOT NULL,
    role              ENUM('student','supervisor','admin') NOT NULL DEFAULT 'student',
    student_id        VARCHAR(30)  DEFAULT NULL UNIQUE,
    department        VARCHAR(100) DEFAULT NULL,
    phone             VARCHAR(30)  DEFAULT NULL,
    bio               TEXT         DEFAULT NULL,
    avatar_path       VARCHAR(255) DEFAULT NULL,
    is_online         TINYINT(1)   NOT NULL DEFAULT 0,
    last_seen         DATETIME     DEFAULT NULL,
    created_at        DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at        DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_role (role),
    INDEX idx_email (email)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ─────────────────────────────────────────────────────────
-- 2. PROJECTS TABLE
-- ─────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS projects (
    id                INT AUTO_INCREMENT PRIMARY KEY,
    title             VARCHAR(255) NOT NULL,
    description       TEXT         DEFAULT NULL,
    student_id        INT NOT NULL,
    supervisor_id     INT DEFAULT NULL,
    status            ENUM('pending','active','under_review','completed','rejected') NOT NULL DEFAULT 'pending',
    progress          TINYINT UNSIGNED NOT NULL DEFAULT 0,
    overall_grade     VARCHAR(5)   DEFAULT NULL,
    final_score       DECIMAL(5,2) DEFAULT NULL,
    start_date        DATE         DEFAULT NULL,
    deadline          DATE         DEFAULT NULL,
    category          VARCHAR(100) DEFAULT NULL,
    tags              VARCHAR(255) DEFAULT NULL,
    created_at        DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at        DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (student_id)   REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (supervisor_id) REFERENCES users(id) ON DELETE SET NULL,
    INDEX idx_student (student_id),
    INDEX idx_supervisor (supervisor_id),
    INDEX idx_status (status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ─────────────────────────────────────────────────────────
-- 3. MILESTONES TABLE
-- ─────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS milestones (
    id            INT AUTO_INCREMENT PRIMARY KEY,
    project_id    INT NOT NULL,
    title         VARCHAR(255) NOT NULL,
    description   TEXT DEFAULT NULL,
    due_date      DATE DEFAULT NULL,
    status        ENUM('pending','in_progress','completed','overdue') NOT NULL DEFAULT 'pending',
    order_num     INT NOT NULL DEFAULT 0,
    created_at    DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (project_id) REFERENCES projects(id) ON DELETE CASCADE,
    INDEX idx_project (project_id),
    INDEX idx_status (status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ─────────────────────────────────────────────────────────
-- 4. FILES/SUBMISSIONS TABLE
-- ─────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS files (
    id                INT AUTO_INCREMENT PRIMARY KEY,
    project_id        INT NOT NULL,
    uploader_id       INT NOT NULL,
    milestone_id      INT DEFAULT NULL,
    original_name     VARCHAR(255) NOT NULL,
    stored_name       VARCHAR(255) NOT NULL,
    file_type         VARCHAR(80)  DEFAULT NULL,
    file_size         BIGINT UNSIGNED DEFAULT NULL,
    submission_type   ENUM('proposal','chapter','report','code','presentation','other') NOT NULL DEFAULT 'other',
    title             VARCHAR(255) DEFAULT NULL,
    notes             TEXT         DEFAULT NULL,
    review_status     ENUM('pending','approved','revision','rejected') NOT NULL DEFAULT 'pending',
    feedback          TEXT         DEFAULT NULL,
    grade             VARCHAR(5)   DEFAULT NULL,
    score             DECIMAL(5,2) DEFAULT NULL,
    reviewed_by       INT          DEFAULT NULL,
    reviewed_at       DATETIME     DEFAULT NULL,
    created_at        DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (project_id)   REFERENCES projects(id) ON DELETE CASCADE,
    FOREIGN KEY (uploader_id)  REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (milestone_id) REFERENCES milestones(id) ON DELETE SET NULL,
    FOREIGN KEY (reviewed_by)  REFERENCES users(id) ON DELETE SET NULL,
    INDEX idx_project (project_id),
    INDEX idx_uploader (uploader_id),
    INDEX idx_status (review_status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ─────────────────────────────────────────────────────────
-- 5. MESSAGES TABLE (Chat)
-- ─────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS messages (
    id            INT AUTO_INCREMENT PRIMARY KEY,
    project_id    INT DEFAULT NULL,
    sender_id     INT NOT NULL,
    receiver_id   INT NOT NULL,
    body          TEXT NOT NULL,
    is_read       TINYINT(1) NOT NULL DEFAULT 0,
    created_at    DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (sender_id)   REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (receiver_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (project_id)  REFERENCES projects(id) ON DELETE SET NULL,
    INDEX idx_sender (sender_id),
    INDEX idx_receiver (receiver_id),
    INDEX idx_created (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ─────────────────────────────────────────────────────────
-- 6. MEETINGS TABLE (Video/In-person Sessions)
-- ─────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS meetings (
    id              INT AUTO_INCREMENT PRIMARY KEY,
    project_id      INT DEFAULT NULL,
    organizer_id    INT NOT NULL,
    participant_id  INT NOT NULL,
    title           VARCHAR(255) NOT NULL,
    agenda          TEXT DEFAULT NULL,
    meeting_type    ENUM('video','in_person','phone') NOT NULL DEFAULT 'video',
    scheduled_at    DATETIME NOT NULL,
    duration_mins   INT NOT NULL DEFAULT 60,
    room_code       VARCHAR(64)  DEFAULT NULL,
    status          ENUM('scheduled','active','completed','cancelled') NOT NULL DEFAULT 'scheduled',
    notes           TEXT DEFAULT NULL,
    recording_url   VARCHAR(255) DEFAULT NULL,
    created_at      DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (organizer_id)   REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (participant_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (project_id)     REFERENCES projects(id) ON DELETE SET NULL,
    INDEX idx_scheduled (scheduled_at),
    INDEX idx_status (status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ─────────────────────────────────────────────────────────
-- 7. NOTIFICATIONS TABLE
-- ─────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS notifications (
    id          INT AUTO_INCREMENT PRIMARY KEY,
    user_id     INT NOT NULL,
    type        VARCHAR(60)  NOT NULL,
    title       VARCHAR(255) NOT NULL,
    body        TEXT         DEFAULT NULL,
    ref_id      INT          DEFAULT NULL,
    ref_type    VARCHAR(60)  DEFAULT NULL,
    is_read     TINYINT(1)   NOT NULL DEFAULT 0,
    created_at  DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    INDEX idx_user_read (user_id, is_read),
    INDEX idx_created (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ─────────────────────────────────────────────────────────
-- 8. ACTIVITY LOG TABLE
-- ─────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS activity_log (
    id          INT AUTO_INCREMENT PRIMARY KEY,
    user_id     INT NOT NULL,
    project_id  INT DEFAULT NULL,
    action      VARCHAR(255) NOT NULL,
    detail      TEXT         DEFAULT NULL,
    created_at  DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id)   REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (project_id) REFERENCES projects(id) ON DELETE SET NULL,
    INDEX idx_user (user_id),
    INDEX idx_created (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ─────────────────────────────────────────────────────────
-- 9. RUBRIC CRITERIA (For grading)
-- ─────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS rubric_criteria (
    id              INT AUTO_INCREMENT PRIMARY KEY,
    project_id      INT DEFAULT NULL,
    supervisor_id   INT NOT NULL,
    criteria_name   VARCHAR(255) NOT NULL,
    max_score       DECIMAL(5,2) NOT NULL DEFAULT 10,
    weight          DECIMAL(3,2) DEFAULT 1.0,
    description     TEXT DEFAULT NULL,
    created_at      DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (project_id)    REFERENCES projects(id) ON DELETE CASCADE,
    FOREIGN KEY (supervisor_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ─────────────────────────────────────────────────────────
-- 10. SUBMISSION GRADES TABLE
-- ─────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS submission_grades (
    id              INT AUTO_INCREMENT PRIMARY KEY,
    file_id         INT NOT NULL UNIQUE,
    supervisor_id   INT NOT NULL,
    score           DECIMAL(5,2) NOT NULL,
    grade           VARCHAR(5)   DEFAULT NULL,
    comments        TEXT DEFAULT NULL,
    graded_at       DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (file_id)       REFERENCES files(id) ON DELETE CASCADE,
    FOREIGN KEY (supervisor_id) REFERENCES users(id) ON DELETE CASCADE,
    INDEX idx_file (file_id),
    INDEX idx_supervisor (supervisor_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ─────────────────────────────────────────────────────────
-- SAMPLE DATA — Insert test data for demo
-- ─────────────────────────────────────────────────────────

-- Password for all demo users: Password123!
-- Hash: $2y$12$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2uheWG/igi.

INSERT INTO users (full_name, email, password_hash, role, student_id, department, bio) VALUES
('Dr. Sarah Mitchell',   'sarah@uni.edu',  '$2y$12$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2uheWG/igi.', 'supervisor', NULL,         'Computer Science', 'Associate Professor specializing in AI with 12 years of research experience.'),
('Dr. James Okonkwo',   'james@uni.edu',  '$2y$12$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2uheWG/igi.', 'supervisor', NULL,         'Engineering',      'Senior Lecturer in Embedded Systems and IoT.'),
('Alice Nguyen',         'alice@uni.edu',  '$2y$12$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2uheWG/igi.', 'student',    'CS/2024/001', 'Computer Science', 'Final year student passionate about AI.'),
('Brian Mensah',         'brian@uni.edu',  '$2y$12$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2uheWG/igi.', 'student',    'ENG/2024/042','Engineering',      'Final year engineering student.'),
('Ada Lovelace',         'ada@uni.edu',    '$2y$12$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2uheWG/igi.', 'student',    'CS/2024/003', 'Computer Science', 'Student focused on machine learning.'),
('Admin User',           'admin@uni.edu',  '$2y$12$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2uheWG/igi.', 'admin',      NULL,         NULL,               NULL);

INSERT INTO projects (title, description, student_id, supervisor_id, status, progress, overall_grade, final_score, start_date, deadline, category) VALUES
('AI-Based Student Attendance System',       'Developing a facial recognition system to automate campus attendance tracking using deep learning.',    3, 1, 'active', 68, NULL, NULL, '2025-01-10', '2025-05-30', 'Artificial Intelligence'),
('Smart Building Energy Management System',  'IoT-based system to monitor and optimize energy consumption across university buildings in real-time.', 4, 2, 'active', 42, NULL, NULL, '2025-01-15', '2025-05-30', 'IoT & Embedded Systems'),
('Mobile Healthcare App',                    'Cross-platform mobile app for patient medical records management and telemedicine consultations.',     5, 1, 'active', 55, NULL, NULL, '2025-01-20', '2025-05-30', 'Mobile Development');

INSERT INTO milestones (project_id, title, description, due_date, status, order_num) VALUES
(1, 'Title & Proposal Approval',   'Submit and get approval for project title and detailed proposal.',       '2025-01-20', 'completed',   1),
(1, 'Literature Review',            'Complete thorough review of 30+ academic sources.',                     '2025-02-10', 'completed',   2),
(1, 'System Design',                'Complete UML diagrams, architecture, and database schema.',             '2025-03-01', 'in_progress', 3),
(1, 'Implementation Phase 1',       'Core facial recognition module — data collection and model training.',  '2025-03-28', 'pending',     4),
(1, 'Testing & Evaluation',         'System testing, performance benchmarking, and UAT.',                   '2025-04-30', 'pending',     5),
(1, 'Final Report & Presentation',  'Submit final report and prepare oral defence presentation.',            '2025-05-30', 'pending',     6),
(2, 'Project Proposal',             'Define scope, objectives, and expected deliverables.',                 '2025-01-25', 'completed',   1),
(2, 'Hardware Procurement & Setup', 'Source IoT sensors and establish dev environment.',                    '2025-02-20', 'completed',   2),
(2, 'Prototype Development',        'Build initial working prototype of sensor network.',                   '2025-03-15', 'in_progress', 3),
(2, 'Data Collection & Analysis',   'Collect real-world energy data and perform analysis.',                 '2025-04-10', 'pending',     4),
(2, 'Final Submission',             'Complete report and demo presentation.',                               '2025-05-30', 'pending',     5),
(3, 'Requirements Analysis',        'Gather and document all functional requirements.',                     '2025-02-01', 'completed',   1),
(3, 'UI/UX Design',                 'Create wireframes and design mockups for mobile app.',                 '2025-02-28', 'in_progress', 2),
(3, 'Backend API Development',      'Develop RESTful APIs and database integration.',                       '2025-03-31', 'pending',     3),
(3, 'Mobile App Implementation',    'Develop native mobile app for iOS and Android.',                       '2025-04-30', 'pending',     4);

INSERT INTO files (project_id, uploader_id, milestone_id, original_name, stored_name, file_type, file_size, submission_type, title, notes, review_status, grade, score) VALUES
(1, 3, 2, 'Chapter1_Intro.pdf', 'proj1_1708256400_abc123.pdf', 'application/pdf', 2156789, 'chapter', 'Chapter 1: Introduction', 'Initial chapter submission', 'approved', 'A', 92.50),
(1, 3, 2, 'Chapter2_Literature.pdf', 'proj1_1708256500_def456.pdf', 'application/pdf', 3245678, 'chapter', 'Chapter 2: Literature Review', 'Comprehensive review of 40 sources', 'approved', 'A', 95.00),
(2, 4, 8, 'Prototype_v1.pdf', 'proj2_1708256600_ghi789.pdf', 'application/pdf', 1906789, 'proposal', 'Prototype Documentation v1', 'Initial prototype design', 'approved', 'B+', 87.50),
(3, 5, 12, 'Wireframes.pdf', 'proj3_1708256700_jkl012.pdf', 'application/pdf', 4567890, 'presentation', 'UI/UX Wireframes', 'Mobile app interface designs', 'pending', NULL, NULL);

INSERT INTO meetings (project_id, organizer_id, participant_id, title, agenda, meeting_type, scheduled_at, duration_mins, room_code, status) VALUES
(1, 1, 3, 'Weekly Progress Check-In',        'Review system design progress and address blockers.',  'video',     '2025-03-01 10:00:00', 60, 'room-fyp-001', 'scheduled'),
(1, 1, 3, 'Chapter 3 Review Session',        'Go through methodology chapter together.',             'in_person', '2025-03-05 14:00:00', 90, NULL,          'scheduled'),
(2, 2, 4, 'Prototype Demo Review',           'Live demonstration of prototype IoT setup.',           'video',     '2025-03-02 11:00:00', 60, 'room-fyp-002', 'scheduled'),
(3, 1, 5, 'Mobile App UI Discussion',        'Discuss wireframes and design improvements.',          'video',     '2025-03-04 15:00:00', 45, 'room-fyp-003', 'scheduled');

INSERT INTO notifications (user_id, type, title, body, ref_id, ref_type, is_read) VALUES
(3, 'feedback',  'Feedback Received',        'Dr. Mitchell reviewed your Chapter 1 submission.',     1, 'file', 0),
(3, 'meeting',   'Meeting Scheduled',        'Progress check-in scheduled for March 1 at 10:00 AM.', 1, 'meeting', 0),
(3, 'milestone', 'Milestone Due Soon',       'System Design milestone is due in 5 days.',            4, 'milestone', 0),
(4, 'feedback',  'Feedback Received',        'Dr. Okonkwo approved your prototype documentation.',   3, 'file', 0),
(5, 'meeting',   'Meeting Scheduled',        'Mobile app discussion scheduled for March 4.',         4, 'meeting', 0),
(1, 'submission','New Submission',           'Alice Nguyen submitted Chapter 1 for review.',         1, 'file', 0),
(2, 'submission','New Submission',           'Brian Mensah submitted prototype documentation.',      3, 'file', 0),
(1, 'submission','New Submission',           'Ada Lovelace submitted UI/UX Wireframes.',             4, 'file', 0);

INSERT INTO activity_log (user_id, project_id, action, detail) VALUES
(3, 1, 'file_uploaded',    'Uploaded: Chapter 1 — Introduction (2.1 MB)'),
(3, 1, 'file_uploaded',    'Uploaded: Chapter 2 — Literature Review (3.1 MB)'),
(1, 1, 'feedback_given',   'Reviewed Chapter 1 — Status: Approved, Grade: A'),
(1, 1, 'feedback_given',   'Reviewed Chapter 2 — Status: Approved, Grade: A'),
(3, 1, 'milestone_updated','Marked Literature Review milestone as completed'),
(4, 2, 'file_uploaded',    'Uploaded: Prototype Documentation (1.8 MB)'),
(2, 2, 'feedback_given',   'Reviewed Prototype Documentation — Status: Approved, Grade: B+'),
(2, 2, 'meeting_scheduled','Scheduled Prototype Demo Review for March 2'),
(5, 3, 'file_uploaded',    'Uploaded: UI/UX Wireframes (4.5 MB)'),
(1, 3, 'meeting_scheduled','Scheduled Mobile App UI Discussion for March 4');

INSERT INTO submission_grades (file_id, supervisor_id, score, grade, comments) VALUES
(1, 1, 92.50, 'A', 'Excellent introduction with clear problem statement. Well-written and structured.'),
(2, 1, 95.00, 'A', 'Comprehensive literature review. Great job covering diverse perspectives and recent research.'),
(3, 2, 87.50, 'B+', 'Good prototype design. Consider adding more technical specifications in next version.');

-- ─────────────────────────────────────────────────────────
-- Create Views for Easy Data Retrieval
-- ─────────────────────────────────────────────────────────

CREATE VIEW supervisor_dashboard_summary AS
SELECT 
    u.id AS supervisor_id,
    u.full_name AS supervisor_name,
    COUNT(DISTINCT p.id) AS total_students,
    COUNT(DISTINCT CASE WHEN p.status = 'active' THEN p.id END) AS active_projects,
    COUNT(DISTINCT CASE WHEN f.review_status = 'pending' THEN f.id END) AS pending_submissions,
    COUNT(DISTINCT CASE WHEN m.scheduled_at > NOW() AND m.status = 'scheduled' THEN m.id END) AS upcoming_meetings
FROM users u
LEFT JOIN projects p ON u.id = p.supervisor_id
LEFT JOIN files f ON p.id = f.project_id
LEFT JOIN meetings m ON p.id = m.project_id AND u.id = m.organizer_id
WHERE u.role = 'supervisor'
GROUP BY u.id, u.full_name;

CREATE VIEW student_project_overview AS
SELECT 
    p.id AS project_id,
    p.title AS project_title,
    u.id AS student_id,
    u.full_name AS student_name,
    sv.id AS supervisor_id,
    sv.full_name AS supervisor_name,
    p.status,
    p.progress,
    COUNT(DISTINCT m.id) AS total_milestones,
    COUNT(DISTINCT CASE WHEN m.status = 'completed' THEN m.id END) AS completed_milestones,
    COUNT(DISTINCT f.id) AS total_submissions,
    COUNT(DISTINCT CASE WHEN f.review_status = 'pending' THEN f.id END) AS pending_reviews,
    AVG(sg.score) AS average_score
FROM projects p
JOIN users u ON p.student_id = u.id
LEFT JOIN users sv ON p.supervisor_id = sv.id
LEFT JOIN milestones m ON p.id = m.project_id
LEFT JOIN files f ON p.id = f.project_id
LEFT JOIN submission_grades sg ON f.id = sg.file_id
GROUP BY p.id, u.id, sv.id;

-- ─────────────────────────────────────────────────────────
-- Indexes for Performance
-- ─────────────────────────────────────────────────────────

CREATE INDEX idx_projects_student_supervisor ON projects(student_id, supervisor_id);
CREATE INDEX idx_files_project_status ON files(project_id, review_status);
CREATE INDEX idx_messages_sender_receiver ON messages(sender_id, receiver_id);
CREATE INDEX idx_meetings_participants ON meetings(organizer_id, participant_id);
CREATE INDEX idx_notifications_user_date ON notifications(user_id, created_at);

-- ============================================================
-- DATABASE INITIALIZATION COMPLETE
-- All tables created with proper relationships, indexes, and sample data.
-- ============================================================
