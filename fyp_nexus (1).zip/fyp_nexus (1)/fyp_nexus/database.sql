-- ============================================================
-- FYP NEXUS — Final Year Project Collaboration Platform
-- Database Schema
-- ============================================================

CREATE DATABASE IF NOT EXISTS fyp_nexus CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE fyp_nexus;

-- ─── USERS ───────────────────────────────────────────────────
CREATE TABLE users (
    id            INT AUTO_INCREMENT PRIMARY KEY,
    full_name     VARCHAR(120) NOT NULL,
    email         VARCHAR(180) NOT NULL UNIQUE,
    password_hash VARCHAR(255) NOT NULL,
    role          ENUM('student','supervisor','admin') NOT NULL DEFAULT 'student',
    student_id    VARCHAR(30)  DEFAULT NULL,
    department    VARCHAR(100) DEFAULT NULL,
    phone         VARCHAR(30)  DEFAULT NULL,
    bio           TEXT         DEFAULT NULL,
    avatar_path   VARCHAR(255) DEFAULT NULL,
    is_online     TINYINT(1)   NOT NULL DEFAULT 0,
    last_seen     DATETIME     DEFAULT NULL,
    created_at    DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at    DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- ─── PROJECTS ────────────────────────────────────────────────
CREATE TABLE projects (
    id              INT AUTO_INCREMENT PRIMARY KEY,
    title           VARCHAR(255) NOT NULL,
    description     TEXT         DEFAULT NULL,
    student_id      INT NOT NULL,
    supervisor_id   INT DEFAULT NULL,
    status          ENUM('pending','active','under_review','completed','rejected') NOT NULL DEFAULT 'pending',
    progress        TINYINT UNSIGNED NOT NULL DEFAULT 0,  -- 0–100
    start_date      DATE DEFAULT NULL,
    deadline        DATE DEFAULT NULL,
    category        VARCHAR(100) DEFAULT NULL,
    tags            VARCHAR(255) DEFAULT NULL,
    created_at      DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at      DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (student_id)   REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (supervisor_id) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB;

-- ─── MILESTONES ──────────────────────────────────────────────
CREATE TABLE milestones (
    id          INT AUTO_INCREMENT PRIMARY KEY,
    project_id  INT NOT NULL,
    title       VARCHAR(255) NOT NULL,
    description TEXT DEFAULT NULL,
    due_date    DATE DEFAULT NULL,
    status      ENUM('pending','in_progress','completed','overdue') NOT NULL DEFAULT 'pending',
    order_num   INT NOT NULL DEFAULT 0,
    created_at  DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (project_id) REFERENCES projects(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- ─── FILES / SUBMISSIONS ─────────────────────────────────────
CREATE TABLE files (
    id              INT AUTO_INCREMENT PRIMARY KEY,
    project_id      INT NOT NULL,
    uploader_id     INT NOT NULL,
    milestone_id    INT DEFAULT NULL,
    original_name   VARCHAR(255) NOT NULL,
    stored_name     VARCHAR(255) NOT NULL,
    file_type       VARCHAR(80)  DEFAULT NULL,
    file_size       BIGINT UNSIGNED DEFAULT NULL,
    submission_type ENUM('chapter','report','code','presentation','other') NOT NULL DEFAULT 'other',
    title           VARCHAR(255) DEFAULT NULL,
    notes           TEXT         DEFAULT NULL,
    review_status   ENUM('pending','approved','revision','rejected') NOT NULL DEFAULT 'pending',
    feedback        TEXT DEFAULT NULL,
    grade           VARCHAR(30)  DEFAULT NULL,
    reviewed_by     INT DEFAULT NULL,
    reviewed_at     DATETIME DEFAULT NULL,
    created_at      DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (project_id)   REFERENCES projects(id) ON DELETE CASCADE,
    FOREIGN KEY (uploader_id)  REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (milestone_id) REFERENCES milestones(id) ON DELETE SET NULL,
    FOREIGN KEY (reviewed_by)  REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB;

-- ─── MESSAGES ────────────────────────────────────────────────
CREATE TABLE messages (
    id          INT AUTO_INCREMENT PRIMARY KEY,
    project_id  INT DEFAULT NULL,
    sender_id   INT NOT NULL,
    receiver_id INT NOT NULL,
    body        TEXT NOT NULL,
    is_read     TINYINT(1) NOT NULL DEFAULT 0,
    created_at  DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (sender_id)   REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (receiver_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (project_id)  REFERENCES projects(id) ON DELETE SET NULL
) ENGINE=InnoDB;

-- ─── MEETINGS ────────────────────────────────────────────────
CREATE TABLE meetings (
    id              INT AUTO_INCREMENT PRIMARY KEY,
    project_id      INT DEFAULT NULL,
    organizer_id    INT NOT NULL,
    participant_id  INT NOT NULL,
    title           VARCHAR(255) NOT NULL,
    agenda          TEXT DEFAULT NULL,
    meeting_type    ENUM('video','in_person','phone') NOT NULL DEFAULT 'video',
    scheduled_at    DATETIME NOT NULL,
    duration_mins   INT NOT NULL DEFAULT 60,
    room_code       VARCHAR(64)  DEFAULT NULL,
    status          ENUM('scheduled','active','completed','cancelled') NOT NULL DEFAULT 'scheduled',
    notes           TEXT DEFAULT NULL,
    created_at      DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (organizer_id)   REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (participant_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (project_id)     REFERENCES projects(id) ON DELETE SET NULL
) ENGINE=InnoDB;

-- ─── NOTIFICATIONS ───────────────────────────────────────────
CREATE TABLE notifications (
    id          INT AUTO_INCREMENT PRIMARY KEY,
    user_id     INT NOT NULL,
    type        VARCHAR(60)  NOT NULL,
    title       VARCHAR(255) NOT NULL,
    body        TEXT         DEFAULT NULL,
    ref_id      INT          DEFAULT NULL,
    ref_type    VARCHAR(60)  DEFAULT NULL,
    is_read     TINYINT(1)   NOT NULL DEFAULT 0,
    created_at  DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- ─── ACTIVITY LOG ────────────────────────────────────────────
CREATE TABLE activity_log (
    id          INT AUTO_INCREMENT PRIMARY KEY,
    user_id     INT NOT NULL,
    project_id  INT DEFAULT NULL,
    action      VARCHAR(255) NOT NULL,
    detail      TEXT         DEFAULT NULL,
    created_at  DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id)   REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (project_id) REFERENCES projects(id) ON DELETE SET NULL
) ENGINE=InnoDB;

-- ─── SAMPLE DATA ─────────────────────────────────────────────
-- Password for all demo users: Password123!
-- Hash: $2y$12$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2uheWG/igi.

INSERT INTO users (full_name, email, password_hash, role, student_id, department, bio) VALUES
('Dr. Sarah Mitchell',   'sarah@uni.edu',  '$2y$12$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2uheWG/igi.', 'supervisor', NULL,         'Computer Science', 'Associate Professor specializing in AI and Machine Learning with 12 years of research experience.'),
('Dr. James Okonkwo',   'james@uni.edu',  '$2y$12$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2uheWG/igi.', 'supervisor', NULL,         'Engineering',      'Senior Lecturer in Embedded Systems and IoT research.'),
('Alice Nguyen',         'alice@uni.edu',  '$2y$12$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2uheWG/igi.', 'student',    'CS/2024/001', 'Computer Science', 'Final year student passionate about AI and data science.'),
('Brian Mensah',         'brian@uni.edu',  '$2y$12$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2uheWG/igi.', 'student',    'ENG/2024/042','Engineering',      'Final year engineering student focusing on smart systems.'),
('Admin User',           'admin@uni.edu',  '$2y$12$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2uheWG/igi.', 'admin',      NULL,         NULL,               NULL);

INSERT INTO projects (title, description, student_id, supervisor_id, status, progress, start_date, deadline, category) VALUES
('AI-Based Student Attendance System',       'Developing a facial recognition system to automate campus attendance tracking using deep learning.',    3, 1, 'active', 68, '2025-01-10', '2025-05-30', 'Artificial Intelligence'),
('Smart Building Energy Management System',  'IoT-based system to monitor and optimize energy consumption across university buildings in real-time.', 4, 2, 'active', 42, '2025-01-15', '2025-05-30', 'IoT & Embedded Systems');

INSERT INTO milestones (project_id, title, description, due_date, status, order_num) VALUES
(1, 'Title & Proposal Approval',   'Submit and get approval for project title and detailed proposal.',       '2025-01-20', 'completed',   1),
(1, 'Literature Review',            'Complete thorough review of 30+ academic sources.',                     '2025-02-10', 'completed',   2),
(1, 'System Design',                'Complete UML diagrams, architecture, and database schema.',             '2025-03-01', 'in_progress', 3),
(1, 'Implementation Phase 1',       'Core facial recognition module — data collection and model training.',  '2025-03-28', 'pending',     4),
(1, 'Testing & Evaluation',         'System testing, performance benchmarking, and UAT.',                   '2025-04-30', 'pending',     5),
(1, 'Final Report & Presentation',  'Submit final report and prepare oral defence presentation.',            '2025-05-30', 'pending',     6),
(2, 'Project Proposal',             'Define scope, objectives, and expected deliverables.',                 '2025-01-25', 'completed',   1),
(2, 'Hardware Procurement & Setup', 'Source IoT sensors and establish dev environment.',                    '2025-02-20', 'completed',   2),
(2, 'Prototype Development',        'Build initial working prototype of sensor network.',                   '2025-03-15', 'in_progress', 3),
(2, 'Data Collection & Analysis',   'Collect real-world energy data and perform analysis.',                 '2025-04-10', 'pending',     4),
(2, 'Final Submission',             'Complete report and demo presentation.',                               '2025-05-30', 'pending',     5);

INSERT INTO meetings (project_id, organizer_id, participant_id, title, agenda, meeting_type, scheduled_at, duration_mins, room_code, status) VALUES
(1, 1, 3, 'Weekly Progress Check-In',        'Review system design progress and address blockers.',  'video',     '2025-03-01 10:00:00', 60, 'room-fyp-001', 'scheduled'),
(1, 1, 3, 'Chapter 3 Review Session',        'Go through methodology chapter together.',             'in_person', '2025-03-05 14:00:00', 90, NULL,          'scheduled'),
(2, 2, 4, 'Prototype Demo Review',           'Live demonstration of prototype IoT setup.',           'video',     '2025-03-02 11:00:00', 60, 'room-fyp-002', 'scheduled');

INSERT INTO notifications (user_id, type, title, body, is_read) VALUES
(3, 'feedback',  'Feedback Received',        'Dr. Mitchell left feedback on your Literature Review submission.', 0),
(3, 'meeting',   'Meeting Scheduled',        'Progress check-in scheduled for March 1 at 10:00 AM.',            0),
(3, 'milestone', 'Milestone Due Soon',       'System Design milestone is due in 5 days.',                       0),
(4, 'feedback',  'Proposal Approved',        'Dr. Okonkwo has approved your project proposal.',                 0),
(1, 'submission','New Submission',           'Alice Nguyen submitted Chapter 3 for review.',                    0),
(2, 'submission','New Submission',           'Brian Mensah submitted prototype documentation.',                  0);

INSERT INTO activity_log (user_id, project_id, action, detail) VALUES
(3, 1, 'file_uploaded',    'Uploaded: Chapter 2 — Literature Review (3.1 MB)'),
(1, 1, 'feedback_given',   'Reviewed Literature Review — Status: Needs Revision'),
(3, 1, 'milestone_updated','Marked Literature Review milestone as completed'),
(4, 2, 'file_uploaded',    'Uploaded: Prototype Documentation (1.8 MB)'),
(2, 2, 'meeting_scheduled','Scheduled Prototype Demo Review for March 2');
